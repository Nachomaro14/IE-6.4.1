package com.socrata;

/**
 * Created with IntelliJ IDEA.
 * User: willpugh
 * Date: 8/15/13
 * Time: 2:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class TestApp
{
}
