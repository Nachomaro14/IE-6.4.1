/**
 * Defines the errors that can happen when using the Socrata APIs defined in com.socrata.api.  The
 * objects in this package should all be POJOs.
 **/
package com.socrata.exceptions;