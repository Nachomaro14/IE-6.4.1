/**
 * Helper objects used by the API implementation.
 **/
package com.socrata.utils;