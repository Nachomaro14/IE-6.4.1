package com.socrata.model.soql;

/**
  */
public enum SortOrder {
    Ascending,
    Descending;
}
