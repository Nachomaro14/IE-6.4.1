/**
 * The model objects (nouns) used for doing searches on the Socrata platform.
 **/
package com.socrata.model.search;