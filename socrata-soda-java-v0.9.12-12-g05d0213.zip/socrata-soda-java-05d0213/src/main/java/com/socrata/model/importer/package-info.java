/**
 * The model objects (nouns) used by the import operations defined by SodaImporter.
 **/
package com.socrata.model.importer;