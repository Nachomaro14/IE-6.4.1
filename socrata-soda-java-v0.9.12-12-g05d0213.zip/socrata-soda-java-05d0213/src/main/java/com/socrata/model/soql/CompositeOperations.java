package com.socrata.model.soql;

/**
 *  Operations allowed for combining operations.
 */
public enum CompositeOperations {
    AND,
    OR;
}
