/**
 * Helper objects to create and manipulate some of the objects defined in com.socrata.model.These are
 * not necassary for using the API, but can be useful.
 **/
package com.socrata.builders;